@include('admin.partials.header')

@yield('content')

@include('admin.partials.footer')