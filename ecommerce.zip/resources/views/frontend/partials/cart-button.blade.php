
<button class="btn btn-outline-dark" type="button" onclick="return addToCart({{ $product->id }})"><i class="fas fa-cart-plus mr-2"></i>Add to cart</button>